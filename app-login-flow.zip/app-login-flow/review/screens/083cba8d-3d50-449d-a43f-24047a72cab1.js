var content='<div class="ui-page" deviceName="iphone13pro" deviceType="mobile" deviceWidth="390" deviceHeight="844">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1673537412147.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-083cba8d-3d50-449d-a43f-24047a72cab1" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="profile" width="390" height="844">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/083cba8d-3d50-449d-a43f-24047a72cab1-1673537412147.css" />\
      <div class="freeLayout">\
      <div id="s-Path_53" class="path firer commentable non-processed" customid="Person circle"   datasizewidth="150.0px" datasizeheight="150.0px" dataX="120.0" dataY="59.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="150.0" height="150.0" viewBox="120.00000000000034 59.0 150.0 150.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_53-083cb" d="M194.96362672488416 209.0 C236.070426841908 209.0 270.00000000000034 175.05401901011288 270.00000000000034 133.99995277746675 C270.00000000000034 92.94581571102077 235.99783369072725 59.0 194.89103357370345 59.0 C153.85689740742265 59.0 120.00000000000034 92.94581571102077 120.00000000000034 133.99995277746675 C120.00000000000034 175.05401901011288 153.92940402580504 209.0 194.96362672488416 209.0 Z M194.96362672488416 159.09651761101412 C174.51910459321635 159.09651761101412 158.64183075710804 166.4224797517648 150.95697093670137 174.83614998254342 C141.0971603632902 164.17360105081679 135.0797836333914 149.81219766428956 135.0797836333914 133.99995277746675 C135.0797836333914 100.70693349566693 161.68677833121217 74.01444773404774 194.89103357370345 74.01444773404774 C228.16812583253437 74.01444773404774 254.92046416507722 100.70693349566693 254.99305731625796 133.99995277746675 C254.99305731625796 149.81219766428956 248.97559798686987 164.17360105081679 239.04326899514922 174.90876249783696 C231.35791357780664 166.4224797517648 215.4807341411147 159.09651761101412 194.96362672488416 159.09651761101412 Z M194.96362672488416 147.20102768825026 C209.02855763277134 147.346276330104 219.9754679516738 135.3055377654864 219.9754679516738 119.78296376803914 C219.9754679516738 105.13106309780449 208.95597234820863 92.8732740295271 194.96362672488416 92.8732740295271 C181.04386638612243 92.8732740295271 169.95176976485848 105.13106309780449 170.02436291603922 119.78296376803914 C170.09694820060193 135.3055377654864 180.9712732349417 147.12840730253453 194.96362672488416 147.20102768825026 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_53-083cb" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="JUAN DELA CRUZ"   datasizewidth="207.9px" datasizeheight="18.0px" dataX="91.0" dataY="221.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">JUAN DELA CRUZ</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="ADMINISTRATOR"   datasizewidth="141.4px" datasizeheight="18.0px" dataX="124.3" dataY="251.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">ADMINISTRATOR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="41.0" dataY="302.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c9957b44-e74f-4600-b744-4ed15ab10aa4.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="249.0" dataY="302.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/2e0d72b7-5250-4597-8d4e-7b46be852871.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="41.0" dataY="495.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/f3a7c476-2a65-4471-88f5-6ed83d66f663.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="100.0px" dataX="249.0" dataY="495.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b263a791-21c4-45ab-8034-c5993d9093ef.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer click ie-background commentable non-processed" customid="Image"   datasizewidth="74.7px" datasizeheight="60.0px" dataX="287.0" dataY="723.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/fbf6a3d7-0549-4d17-82d9-5a63a4600b78.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Inventory Items"   datasizewidth="164.6px" datasizeheight="18.0px" dataX="8.7" dataY="413.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Inventory Items</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="QR SCAN"   datasizewidth="90.9px" datasizeheight="18.0px" dataX="254.0" dataY="413.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">QR SCAN</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Add Items"   datasizewidth="103.9px" datasizeheight="18.0px" dataX="20.4" dataY="605.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Add Items</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Reports"   datasizewidth="78.6px" datasizeheight="18.0px" dataX="259.7" dataY="605.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Reports</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;