var content='<div class="ui-page" deviceName="iphone11pro" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1024" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1673537412147.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7" class="screen growth-both devMobile devIOS iphone-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="Login" width="375" height="812">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7-1673537412147.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Home_Indicator"   datasizewidth="134.0px" datasizeheight="5.0px" datasizewidthpx="134.0" datasizeheightpx="5.0" dataX="120.5" dataY="795.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer click ie-background commentable non-processed" customid="Don&rsquo;t-have-an-account"   datasizewidth="181.8px" datasizeheight="15.0px" dataX="101.7" dataY="623.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Don&rsquo;t have an account? &nbsp;</span><span id="rtr-s-Paragraph_1_1">Register!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Form" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Login button"   datasizewidth="332.4px" datasizeheight="57.0px" dataX="22.7" dataY="520.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">LOGIN</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Forgot-password?"   datasizewidth="104.7px" datasizeheight="16.0px" dataX="123.7" dataY="592.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">Forgot password?</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Email Input" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Input_6" class="text firer commentable non-processed" customid="Input search"  datasizewidth="330.0px" datasizeheight="55.0px" dataX="24.0" dataY="361.0" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="juandelacruz@gmail.com"/></div></div>  </div></div></div>\
          <div id="s-Paragraph_9" class="richtext manualfit firer ie-background commentable non-processed" customid="Description"   datasizewidth="80.7px" datasizeheight="16.0px" dataX="47.0" dataY="371.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_9_0">Email</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Paragraph_10" class="richtext autofit firer ie-background commentable non-processed" customid="Keep your data safe"   datasizewidth="106.2px" datasizeheight="15.0px" dataX="134.4" dataY="278.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0">Keep your data safe</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="richtext autofit firer ie-background commentable non-processed" customid="Welcome to LemonPie!"   datasizewidth="243.3px" datasizeheight="27.0px" dataX="65.9" dataY="240.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0">Welcome to Small Depot</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="iPhone status bar" datasizewidth="375.0px" datasizeheight="44.0px" >\
        <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle_30"   datasizewidth="375.0px" datasizeheight="44.0px" datasizewidthpx="375.0" datasizeheightpx="44.0" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Time"   datasizewidth="36.0px" datasizeheight="18.0px" dataX="25.0" dataY="16.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">9:4</span><span id="rtr-s-Paragraph_8_1">1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Battery icon" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Path_20" class="path firer ie-background commentable non-processed" customid="Border"   datasizewidth="23.0px" datasizeheight="12.3px" dataX="336.0" dataY="16.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="23.0" height="12.333333015441895" viewBox="336.0 16.0 23.0 12.333333015441895" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_20-567ee" d="M339.6666667461395 17.0 L355.3333332538605 17.0 C356.79622335173764 17.0 358.0 18.20377664826237 358.0 19.666666746139526 L358.0 24.666666269302368 C358.0 26.129556367179525 356.79622335173764 27.333333015441895 355.3333332538605 27.333333015441895 L339.6666667461395 27.333333015441895 C338.20377664826236 27.333333015441895 337.0 26.129556367179525 337.0 24.666666269302368 L337.0 19.666666746139526 C337.0 18.20377664826237 338.20377664826236 17.0 339.6666667461395 17.0 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_20-567ee" fill="none" stroke-width="1.0" stroke="#000000" stroke-linecap="butt" opacity="0.35"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_21" class="path firer commentable non-processed" customid="Cap"   datasizewidth="1.3px" datasizeheight="4.0px" dataX="359.0" dataY="20.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="1.3280372619628906" height="4.0" viewBox="359.0 20.0 1.3280372619628906 4.0" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_21-567ee" d="M359.0 20.0 L359.0 24.0 C359.80473136901855 23.66122341156006 360.3280372619629 22.873133182525635 360.3280372619629 22.0 C360.3280372619629 21.126866817474365 359.80473136901855 20.33877658843994 359.0 20.0 "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_21-567ee" fill="#000000" fill-opacity="1.0" opacity="0.4"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
          <div id="s-Path_22" class="path firer commentable non-processed" customid="Capacity"   datasizewidth="17.0px" datasizeheight="6.3px" dataX="339.0" dataY="19.0"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="17.0" height="6.333333969116211" viewBox="339.0 19.0 17.0 6.333333969116211" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_22-567ee" d="M340.33333337306976 19.0 L354.66666662693024 19.0 C355.3981116758688 19.0 356.0 19.601888324131185 356.0 20.333333373069763 L356.0 24.00000011920929 C356.0 24.731445168147868 355.3981116758688 25.333333492279053 354.66666662693024 25.333333492279053 L340.33333337306976 25.333333492279053 C339.6018883241312 25.333333492279053 339.0 24.731445168147868 339.0 24.00000011920929 L339.0 20.333333373069763 C339.0 19.601888324131185 339.6018883241312 19.0 340.33333337306976 19.0 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_22-567ee" fill="#000000" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_23" class="path firer commentable non-processed" customid="Wifi Icon"   datasizewidth="15.3px" datasizeheight="11.0px" dataX="316.0" dataY="18.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="15.272381782531738" height="10.965571403503418" viewBox="315.99999996123876 18.0 15.272381782531738 10.965571403503418" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_23-567ee" d="M323.6366033166465 20.27732753753662 C325.85251518188085 20.277424812316895 327.9836797326621 21.12886333465576 329.589606246334 22.655661582946777 C329.71054740844335 22.77353572845459 329.9038457482871 22.772047996520996 330.022955855709 22.65232753753662 L331.178961715084 21.485661506652832 C331.239264449459 21.424939155578613 331.2728948205527 21.342686653137207 331.2723760217246 21.257107734680176 C331.2718877404746 21.17152690887451 331.23728080688085 21.089673042297363 331.176276168209 21.02966022491455 C326.961188277584 16.990113258361816 320.31137748656835 16.990113258361816 316.09628959594335 21.02966022491455 C316.0352239221152 21.08962917327881 316.00058647094335 21.171456336975098 316.000006636959 21.25703716278076 C315.9994573205527 21.342617988586426 316.0330266564902 21.42489528656006 316.093268355709 21.485661506652832 L317.24960990844335 22.65232753753662 C317.368658980709 22.772229194641113 317.5620793908652 22.773716926574707 317.68295951781835 22.655661582946777 C319.2890996545371 21.128762245178223 321.42050834594335 20.277321815490723 323.6366033166465 20.27732753753662 L323.6366033166465 20.27732753753662 Z M323.6366033166465 24.07299518585205 C324.85410209594335 24.07292079925537 326.0281438439902 24.525452613830566 326.9306096643027 25.34266185760498 C327.0526799768027 25.45864200592041 327.24497123656835 25.456128120422363 327.3639592736777 25.336995124816895 L328.5186223596152 24.170327186584473 C328.5794133752402 24.109131813049316 328.6131658166465 24.026116371154785 328.612311324459 23.93985080718994 C328.6113957971152 23.85358715057373 328.5759954064902 23.771273612976074 328.5139531701621 23.71132755279541 C325.7657537072715 21.154946327209473 321.5098027795371 21.154946327209473 318.7616033166465 23.71132755279541 C318.6995305627402 23.771273612976074 318.6641301721152 23.85362720489502 318.6632756799277 23.939919471740723 C318.6624822228965 24.02621364593506 318.6963567346152 24.10922145843506 318.7572698205527 24.170327186584473 L319.911627730709 25.336995124816895 C320.03061576781835 25.456128120422363 320.22287651000585 25.45864200592041 320.34494682250585 25.34266185760498 C321.246832808834 24.525992393493652 322.419928511959 24.073498725891113 323.6366033166465 24.07299518585205 L323.6366033166465 24.07299518585205 Z M325.8556279748496 26.857327461242676 C325.9173650353965 26.79672145843506 325.95139213500585 26.713318824768066 325.9496221154746 26.62681293487549 C325.94785209594335 26.540305137634277 325.9104680627402 26.458361625671387 325.84628959594335 26.400328636169434 C324.5707158654746 25.321444511413574 322.7025212853965 25.321444511413574 321.4269475549277 26.400328636169434 C321.3627385705527 26.4583158493042 321.32529350219335 26.54023265838623 321.32346244750585 26.62674045562744 C321.32163139281835 26.713248252868652 321.35556693969335 26.79667568206787 321.4172734826621 26.857327461242676 L323.4149541467246 28.872994422912598 C323.47348686156835 28.93223285675049 323.55332084594335 28.965571403503418 323.6366033166465 28.965571403503418 C323.7199163049277 28.965571403503418 323.7997197717246 28.93223285675049 323.8582830041465 28.872994422912598 L325.8556279748496 26.857327461242676 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_23-567ee" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_24" class="path firer commentable non-processed" customid="Cellular Connection icon"   datasizewidth="17.0px" datasizeheight="10.7px" dataX="294.0" dataY="18.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="17.0" height="10.666667938232422" viewBox="294.0 18.0 17.0 10.666667938232422" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_24-567ee" d="M295.0 24.666667938232422 L296.0 24.666667938232422 C296.55230712890625 24.666667938232422 297.0 25.114381790161133 297.0 25.666667938232422 L297.0 27.666667938232422 C297.0 28.218952178955078 296.55230712890625 28.666667938232422 296.0 28.666667938232422 L295.0 28.666667938232422 C294.4477233886719 28.666667938232422 294.0 28.218952178955078 294.0 27.666667938232422 L294.0 25.666667938232422 C294.0 25.114381790161133 294.4477233886719 24.666667938232422 295.0 24.666667938232422 L295.0 24.666667938232422 Z M299.66668701171875 22.666667938232422 L300.66668701171875 22.666667938232422 C301.2189636230469 22.666667938232422 301.66668701171875 23.114381790161133 301.66668701171875 23.666667938232422 L301.66668701171875 27.666667938232422 C301.66668701171875 28.218952178955078 301.2189636230469 28.666667938232422 300.66668701171875 28.666667938232422 L299.66668701171875 28.666667938232422 C299.1143798828125 28.666667938232422 298.66668701171875 28.218952178955078 298.66668701171875 27.666667938232422 L298.66668701171875 23.666667938232422 C298.66668701171875 23.114381790161133 299.1143798828125 22.666667938232422 299.66668701171875 22.666667938232422 Z M304.3333435058594 20.33333396911621 L305.3333435058594 20.33333396911621 C305.8856201171875 20.33333396911621 306.3333435058594 20.781049728393555 306.3333435058594 21.33333396911621 L306.3333435058594 27.666667938232422 C306.3333435058594 28.218952178955078 305.8856201171875 28.666667938232422 305.3333435058594 28.666667938232422 L304.3333435058594 28.666667938232422 C303.78106689453125 28.666667938232422 303.3333435058594 28.218952178955078 303.3333435058594 27.666667938232422 L303.3333435058594 21.33333396911621 C303.3333435058594 20.781049728393555 303.78106689453125 20.33333396911621 304.3333435058594 20.33333396911621 Z M309.0 18.0 L310.0 18.0 C310.55230712890625 18.0 311.0 18.447715759277344 311.0 19.0 L311.0 27.666667938232422 C311.0 28.218952178955078 310.55230712890625 28.666667938232422 310.0 28.666667938232422 L309.0 28.666667938232422 C308.4477233886719 28.666667938232422 308.0 28.218952178955078 308.0 27.666667938232422 L308.0 19.0 C308.0 18.447715759277344 308.4477233886719 18.0 309.0 18.0 L309.0 18.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_24-567ee" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="150.0px" datasizeheight="150.0px" dataX="112.5" dataY="82.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/70672a79-3e4b-4f61-98c6-7db0cb387a98.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="password firer commentable non-processed" customid="Input search"  datasizewidth="330.0px" datasizeheight="55.0px" dataX="22.5" dataY="429.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="***********"/></div></div></div></div></div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Description"   datasizewidth="80.7px" datasizeheight="16.0px" dataX="45.8" dataY="431.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Password</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;