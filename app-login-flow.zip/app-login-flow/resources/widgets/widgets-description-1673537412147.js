	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_53", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ""; 

			widgets.rootWidgetMap[["s-Path_53", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ["Person circle", "s-Path_53"]; 

	widgets.descriptionMap[["s-Image", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_3", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "083cba8d-3d50-449d-a43f-24047a72cab1"]] = ["Image", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image", "567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Rect_11", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ""; 

			widgets.rootWidgetMap[["s-Rect_11", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ["Square", "s-Rect_11"]; 

	widgets.descriptionMap[["s-Path_241", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ""; 

			widgets.rootWidgetMap[["s-Path_241", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ["Lock", "s-Path_241"]; 

	widgets.descriptionMap[["s-Image_2", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ["Text Area", "s-TextArea"]; 

	widgets.descriptionMap[["s-Input_2", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "832e1048-c79b-42fd-8e14-093a6644cbe7"]] = ["Text Area", "s-TextArea"]; 

	widgets.descriptionMap[["s-Image_1", "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Category_2", "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab"]] = ["Select list", "s-Category_2"]; 

	widgets.descriptionMap[["s-Category_1", "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab"]] = ["Select list", "s-Category_1"]; 

	