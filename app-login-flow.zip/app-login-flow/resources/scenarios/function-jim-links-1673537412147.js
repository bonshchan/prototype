(function(window, undefined) {

  var jimLinks = {
    "083cba8d-3d50-449d-a43f-24047a72cab1" : {
      "Image_4" : [
        "567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7"
      ]
    },
    "567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7" : {
      "Paragraph_1" : [
        "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab"
      ],
      "Button_1" : [
        "083cba8d-3d50-449d-a43f-24047a72cab1"
      ]
    },
    "832e1048-c79b-42fd-8e14-093a6644cbe7" : {
      "Button_2" : [
        "567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7"
      ]
    },
    "fa4e9fb0-cb6e-4573-a2e4-c316a178e6ab" : {
      "Image_1" : [
        "567eeee5-f0cc-48b1-a6ca-8ca6198ae1a7"
      ],
      "Button_1" : [
        "3b816b34-2fc8-4f55-9ab0-289c22e4d6b9"
      ]
    },
    "3b816b34-2fc8-4f55-9ab0-289c22e4d6b9" : {
      "Button_2" : [
        "832e1048-c79b-42fd-8e14-093a6644cbe7"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);